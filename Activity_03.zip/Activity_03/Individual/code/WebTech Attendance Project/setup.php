<?php
// will run once to create DB and table 

$host = 'localhost';
$user = 'root';
$pass = '';

try {
    // Connect without specific DB first
    $pdo = new PDO("mysql:host=$host", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create database if there isn one
    $pdo->exec("CREATE DATABASE IF NOT EXISTS attendance_db");

    // Connect to new DB
    $pdo->exec("USE attendance_db");

    // Create users table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) NOT NULL,
            email VARCHAR(100) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            role VARCHAR(50) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");

    echo "<p>✅ Database and table setup complete.</p>";
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>