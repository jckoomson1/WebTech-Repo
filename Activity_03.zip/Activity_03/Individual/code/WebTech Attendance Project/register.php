<?php
require_once 'config.php';
session_start();
$message = $_SESSION['message'] ?? '';
unset($_SESSION['message']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Registration - Ashesi Attendance Portal</title>
  <link rel="stylesheet" href="../../group/code/userregistrationstyle.css">
</head>
<body>
  <h1><img src="../../group/code/Ashesi_logo-removebg-preview.png" alt="Ashesi Logo" class="center"><br></h1>
  
  <h1 class="registration-title">User Registration</h1>
  <h2 class="registration-subtitle">Create your account:</h2>

  <?php if ($message): ?>
      <p style="text-align:center; color:green;"><?php echo htmlspecialchars($message); ?></p>
  <?php endif; ?>

  <form action="register_action.php" method="POST">
    <label for="reg-name">Full Name:</label>
    <input type="text" id="reg-name" name="name" required>

    <label for="reg-email">Email:</label>
    <input type="email" id="reg-email" name="email" required>

    <label for="reg-password">Password:</label>
    <input type="password" id="reg-password" name="password" required minlength="8">
    <small id="password-help">Password must be at least 8 characters.</small>

    <label for="role">Role:</label>
    <select id="role" name="role" required>
      <option value="">--Please select--</option>
      <option value="student">Student</option>
      <option value="faculty">Faculty Intern</option>
    </select>

    <button type="submit">Register</button>
  </form>

  <p><font color="green">Already have an account? </font><a href="../../group/code/index.html"><font color="cyan">Login here</font></a></p>

  <hr>
  <h2 class="registration-subtitle">Registered Users</h2>

  <?php
  try {
      $stmt = $pdo->query("SELECT name, email, role FROM users ORDER BY id DESC");
      $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

      if ($users) {
          echo "<table style='width:90%;margin:auto;background:white;color:black;border-collapse:collapse;'>";
          echo "<tr><th style='padding:8px;border:1px solid #ccc;'>Name</th><th style='padding:8px;border:1px solid #ccc;'>Email</th><th style='padding:8px;border:1px solid #ccc;'>Role</th></tr>";
          foreach ($users as $u) {
              echo "<tr>
                        <td style='padding:8px;border:1px solid #ccc;'>".htmlspecialchars($u['name'])."</td>
                        <td style='padding:8px;border:1px solid #ccc;'>".htmlspecialchars($u['email'])."</td>
                        <td style='padding:8px;border:1px solid #ccc;'>".htmlspecialchars($u['role'])."</td>
                    </tr>";
          }
          echo "</table>";
      } else {
          echo "<p style='text-align:center;'>No users registered yet.</p>";
      }
  } catch (PDOException $e) {
      echo "<p style='text-align:center;color:red;'>Error fetching users: ".$e->getMessage()."</p>";
  }
  ?>
</body>
</html>