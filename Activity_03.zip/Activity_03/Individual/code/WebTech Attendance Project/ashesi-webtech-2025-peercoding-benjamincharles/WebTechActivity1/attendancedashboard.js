document.addEventListener("DOMContentLoaded", () => {
  const submitCodeBtn = document.getElementById("submitCodeBtn");

  submitCodeBtn.addEventListener("click", () => {
    const sessionCode = document.getElementById("sessionCode").value.trim();

    if (sessionCode === "") {
      alert("N/A");
      return;
    }

    // Example — replace this later with backend
    alert(`Attendance marked for code: ${sessionCode}`);
    document.getElementById("sessionCode").value = "";
  });
});